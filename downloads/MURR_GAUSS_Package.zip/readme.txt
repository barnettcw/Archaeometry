
=========================================================
Installing the Gauss Runtime and MURR Statistics Routines
=========================================================


This distribution consists of three files:

gaussruntime.zip (Gauss Runtime Module Installer)
dm.exe (Self-extracting Archive Containing MURR routines and Dataset Manipulator)
readme.txt: Installation instructions


Installation instructions

Open the "gaussruntime.zip" by double-clicking the program
icon.  You will need to have a ZIP archive program (such as
WinZIP) to do this.  Whne the archive opens, you will see a
list of files, one of which is called "setup.exe".  Double-
click this program to start the installation process.  When
prompted, accept all of the defaults offered by the
installation program.  When done, you should have a new
icon on your desktop called "Gsrun 5.0" and the program
should have been installed on your C: drive in a new
directory called "Gsrun50".

When you are done installing the Gauss runtime, you need
to run the "dm.exe" program to install the MURR routines.
Double-click the dm.exe program icon to do this. 

You will be asked to enter the password that was sent to you via email.

Accept all default settings.  You should now have a second icon
on your desktop, this one called "Shortcut to gsrun.exe".

"Right Click" on the gsrun.exe icon. Select properties. 
The target will be C:\GSRUN50\gsrun.exe 

CHANGE the target to C:\GSRUN50\gsrun.exe sarmenu.gcg 

To double check the installation, go to the "Gsrun50"
directory on your C: drive.  You should have the following
files in that directory:

     dlib     (directory)
     pthreads (directory)
     tmp      (directory)
     3plot.gcg
     bigdisc.gcg
     class.gcg
     cluster.gcg
     cmx20.dll
     complex.fnt
     compobj.dll
     concat.gcg
     concat2.gcg
     convert.gcg
     DMHelp.chm
     eucserch.gcg
     export.gcg
     gauss.chm
     gauss.dll
     gauss.ico
     gaussreference.chm
     genpc.gcg
     gsrun.cfg
     gsrun.exe
     import.dll
     import.gcg
     intrins.hdx
     listdata.gcg
     logdat.gcg
     manip.exe
     microb.fnt
     missdat.gcg
     mplot.gcg
     MURRHelp.chm
     opnx32.dll
     proj.gcg
     pthreadVC.dll
     README.vwr.txt
     sarmenu.gcg
     simgrma.fnt
     simplex.fnt
     source1.gcg
     source2.gcg
     sumstat.gcg
     symbol.gpc
     td.exe
     tgsrun.exe
     tips.txt
     vexcel.gcg
     vwr.exe
     xls.dll

Once you check the installation, you are ready to start
using the program.  To start, double-click the new icon
on your desktop, and select option #15 to view the help
file.  All of the routines will be opened through the
text interface and the 16 options shown here (you should
see this same display when you open the program using
the desktop icon):

 Here are the options available:
    1.  Specimen sourcing routines.
    2.  Missing values substitution.
    3.  Transform a dataset.
    4.  Dataset manipulation routines.
    5.  List values of variables in a dataset.
    6.  Obtain summary statistics for a dataset.
    7.  Hierarchical cluster analysis.
    8.  Principal components analysis.
    9.  Canonical discriminant analysis.
   10.  Classify specimens using Mahalanobis distance.
   11.  Project specimens using Mahalanobis distance.
   12.  2D scatterplots.
   13.  3D scatterplots.
   14.  Convert all v89 files to v96 format in current directory.
   15.  Help files.
   16.  Exit program.

 Choice (default=Exit program)?


Once you have read the help file, you should be able to
begin using the statistical routines with very little
trouble.  It will take time to get familiar with all of
the options and the steps required to do the various
tasks, so it is suggested that you start with some simple
data and try out the various routines.  Start with
a small Excel spreadsheet (see the Introduction on the
help file for details about formatting the spreadsheet)
and try importing it into Gauss (option 4-3).  Then do
some transformations or plots to get familiar with the
software.

NOTE:  DO NOT open any of the .gcg files in the "gsrun50"
directory by using File|Open on the Gauss menu.  You risk
corrupting the files if you do this.  If you have any problems
where the routines will not start at all, you may need to
re-run the dm.exe installation program to renew your
program files.


=========================================================
